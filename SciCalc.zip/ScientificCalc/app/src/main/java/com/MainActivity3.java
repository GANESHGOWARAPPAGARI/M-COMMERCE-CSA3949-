package com;

import android.app.Activity;

public class MainActivity3 extends Activity {
}
